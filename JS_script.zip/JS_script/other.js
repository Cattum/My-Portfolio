document.getElementById("exploreBtn").addEventListener("click", () => {
    window.scrollTo({
      top: document.querySelector(".content").offsetTop,
      behavior: "smooth"
    });
  });
  

  document.getElementById("contactForm").addEventListener("submit", (e) => {
    e.preventDefault();
    alert("感谢您的留言！");
  });